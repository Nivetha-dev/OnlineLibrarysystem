﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Text;

namespace LibData.Models
{
    public class LibraryBranch
    {
        public int Id { get; set; }
        [Required]
        [StringLength(30)]
        public String Name { get; set; }
        [Required]
        public String Address { get; set; }
        [Required]
        public String Telephone { get; set; }
        public String Description { get; set; }
        public DateTime OpenDate { get; set; }
        public virtual IEnumerable<patron> Patrons { get; set; }
        public virtual IEnumerable<LibraryAsset> LibraryAsset { get; set; }
        public String ImageUrl { get; set; }
    }
}
