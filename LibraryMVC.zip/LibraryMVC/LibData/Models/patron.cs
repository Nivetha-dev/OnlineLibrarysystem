﻿using System;
using System.Collections.Generic;
using System.Text;

namespace LibData.Models
{
    public class patron
    {
        public int ID { get; set; }
        public string firstname { get; set; }
        public string lastname { get; set; }
        public string address { get; set; }
        public DateTime dateofbirth { get; set; }
        public string telephonenumber { get; set; }
        public LibraryCard LibraryCard { get; set; }
        public LibraryBranch HomeLibraryBranch { get; set; }

    }
}
