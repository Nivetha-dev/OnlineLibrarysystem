﻿using LibData.Models;
using Microsoft.EntityFrameworkCore;

namespace LibData
{
    public class LibraryContext : DbContext
    {
        public LibraryContext(DbContextOptions options) : base(options) {
        }
        public DbSet<patron> patrons { get; set; }
        public DbSet<Book> Books { get; set; }
        public DbSet<BranchHours> BranchHourses { get; set; }
        public DbSet<Checkout> Checkouts { get; set; }
        public DbSet<CheckoutHistory> CheckoutHistorys { get; set; }
        public DbSet<Hold> Holds { get; set; }
        public DbSet<LibraryAsset> LibraryAssets { get; set; }
        public DbSet<LibraryBranch> LibraryBranchs { get; set; }
        public DbSet<LibraryCard> LibraryCards { get; set; }
        public DbSet<Status> Statuses { get; set; }
        public DbSet<Video> Videos { get; set; }
    }
}
