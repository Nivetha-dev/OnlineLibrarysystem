﻿using System;
using System.Collections.Generic;
using System.Linq;
using LibData;
using LibData.Models;
using Microsoft.EntityFrameworkCore;

namespace LibServices
{
    public class LibraryAssetService : ILibraryAsset
    {
        public LibraryContext _context;
        public LibraryAssetService(LibraryContext context) 
        {
            _context = context;
        }
        public void Add(LibraryAsset newAsset)
        {
            _context.Add(newAsset);
            _context.SaveChanges();
        }

        public IEnumerable<LibraryAsset> GetAll()
        {
            return _context.LibraryAssets
                .Include(asset => asset.Status)
                .Include(asset => asset.Location);
        }


        public LibraryAsset GetById(int id)
        {
            return GetAll()
                .FirstOrDefault(asset => asset.Id==id);
        }

        public LibraryBranch GetCurrentLocation(int id)
        {
            return GetById(id).Location;
        }

        public string GetDeweyIndex(int id)
        {
            if (_context.Books.Any(Book => Book.Id == id))
                {
                return _context.Books.FirstOrDefault(book => book.Id == id).DeweyIndex;
            }
            else
                return "";
        }

        public string GetIsbn(int id)
        {
            if (_context.Books.Any(Book => Book.Id == id))
                {
                return _context.Books.FirstOrDefault(book => book.Id == id).ISBN;
            }
            else
                return "";
        }

        public string GetTitle(int id)
        {
            return _context.LibraryAssets.FirstOrDefault(book => book.Id == id).Title;
        }
        public string GetAuthorOrDirector(int id)
        {
            //return "fg";
            var isBook = _context.LibraryAssets.OfType<Book>().Where(asset => asset.Id == id).Any();
            // var isVideo = _context.LibraryAssets.OfType<Video>().Where(asset => asset.Id == id).Any();
               return isBook ? _context.Books.FirstOrDefault(Book => Book.Id == id).Author :
                 _context.Videos.FirstOrDefault(Book => Book.Id == id).Director ?? "Unknown";
        }
        public string GetType(int id)
        {
            var Book = _context.LibraryAssets.OfType<Book>().Where(asset => asset.Id == id);
            //var isVideo = _context.LibraryAssets.OfType<Video>().Where(asset => asset.Id == id).Any();
            return Book.Any() ? "Book" : "Video";
        }

       
    }
}
