﻿using LibData.Models;
using System;
using System.Collections.Generic;
using System.Text;

namespace LibData
{
    public interface ILibraryAsset
    {
        IEnumerable<LibraryAsset> GetAll();
        LibraryAsset GetById(int id);
        void Add(LibraryAsset newAsset);
        String GetAuthorOrDirector(int id);
        String GetDeweyIndex(int id);
        String GetType(int id);
        String GetTitle(int id);
        String GetIsbn(int id);

        LibraryBranch GetCurrentLocation(int id);
    }
}
