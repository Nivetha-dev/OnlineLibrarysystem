﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Text;

namespace LibData.Models
{
    public class Video: LibraryAsset
    {
        [Required]
        public String Director { get; set; }
    }
}
