﻿using System;
using System.Collections.Generic;
using System.Text;

namespace LibData.Models
{
    public class LibraryCard
    {
        public int Id { get; set; }
        public decimal fees { get; set; }
        public DateTime Created { get; set; }
        public virtual IEnumerable<Checkout> Checkouts { get; set; }
    }
}
